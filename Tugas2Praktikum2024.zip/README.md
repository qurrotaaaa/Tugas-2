<<<<<<< HEAD
# Tugas Pertemuan 2


=======
# Tugas-2
>>>>>>> 887f91a1d0e5616f92d1aaae5a4d9a55e464359a
Nama : Qurrota A'yun

NIM : H1D022051

Shift Baru: e
<<<<<<< HEAD

=======
>>>>>>> 887f91a1d0e5616f92d1aaae5a4d9a55e464359a
